#include "cApp.h"

wxIMPLEMENT_APP(cApp);

cApp::cApp() {

}

cApp::~cApp() {

	
}

bool cApp::OnInit() {
	m_fram1 = new cMain();
	m_fram1->Show(); 
	return true;
}